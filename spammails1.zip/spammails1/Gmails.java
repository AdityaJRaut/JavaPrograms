package spammails1;
import java.io.Console;
import java.io.FileWriter;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Enumeration;
public class Gmails extends javax.swing.JFrame {
public Gmails()  
{
        initComponents();
}
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton1.setText("TRAINING  DATASET");
        jButton1.setAlignmentY(0.0F);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("ARFF");
        jButton2.setAlignmentY(0.0F);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(228, 228, 228)
                        .addComponent(jButton2)))
                .addContainerGap(172, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jButton2)
                .addContainerGap(176, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
// TODO add your handling code here:
    
    GmailInboxnew g=new GmailInboxnew();
    g.read();
}//GEN-LAST:event_jButton1ActionPerformed

private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
// TODO add your handling code here:
        try
         {     
         Class.forName("com.mysql.jdbc.Driver");
         Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/emailspam","root","");
         Statement st1=conn.createStatement();
         ResultSet rs=st1.executeQuery("select * from feature_spam");
         ResultSetMetaData rsmd=rs.getMetaData();
         int cnt=rsmd.getColumnCount();
         rs.close();
         ArrayList cols=new ArrayList();
         for(int i=1;i<=cnt;i++)
         {
             cols.add(rsmd.getColumnName(i));
         }
            FileWriter sw = new FileWriter("D:\\Email.arff");
            sw.write("@relation mails");
            sw.write("\r\n");
            sw.write("");
            for (int i = 0; i <cnt-1; i++)
            {
                sw.write("@attribute " + cols.get(i).toString() + " real");
                sw.write("\r\n");
            }
            sw.write("@attribute result {Clear,Spam,TME}");
            sw.write("\r\n");
            sw.write("@data");
            sw.write("\r\n");
            sw.flush();
            rs=st1.executeQuery( "Select * from feature_table2");
         //  SqlDataReader dr = cmd.ExecuteReader();
            int fll = 0;
            int k = 0;
            while (rs.next())
            {

                for (k = 0; k < 47; k++)
                {
                    // Conditions for TME
                    if ((rs.getString(40).equals("1") && rs.getString(11).equals("1") && rs.getString(1).equals("0")) || (rs.getString(25).equals("1")))
                    {
                        if ((rs.getString(27).equals("1") || rs.getString(30).equals("1") || rs.getString(31).equals("1")) && (rs.getString(3).equals("1") || rs.getString(5).equals("1") || rs.getString(4).equals("1")) && (rs.getString(24).equals("1") || rs.getString(22).equals("1")))
                        {
                            fll = 2;
                            break;
                        }
                    }

                    // Conditions for Spam
                    if (rs.getString(3).equals("1") || rs.getString(5).equals("1") || rs.getString(4).equals("1") || rs.getString(21).equals("1") || rs.getString(22).equals("1"))
                    {
                        fll = 1;
                      //  break;
                    }
                   // sw.Write(dr[k].ToString() + " ");
                }

                if (fll == 0)
                {

                    k = 1;
                    do
                    {
                        sw.write(rs.getString(k) + " ");

                        k++;

                    } while (k < 47);

                    sw.write("Clear");
                    sw.write("\r\n");
                }
                else if (fll == 1)
                {
                    // sw.Write(dr[k].ToString() + " ");
                    k = 1;
                    do
                    {
                       sw.write(rs.getString(k) + " ");

                        k++;

                    } while (k < 47);

                    sw.write("Spam");
                    sw.write("\r\n");


                }
                else if (fll == 2)
                {
                      k = 1;
                    do
                    {
                        sw.write(rs.getString(k) + " ");

                        k++;

                    } while (k < 47);
                    sw.write("TME");
                    sw.write("\r\n");
                }
                fll = 0;

                //while (dr.Read())

            }

            sw.flush();
            rs.close();
            sw.close();


         
         
         }
        catch(Exception e)
        {
          System.out.println(e)  ;
        }
    
    
}//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gmails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gmails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gmails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gmails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Gmails().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
 class GmailInboxnew {

        String id, pwd;
        String from="";
       // string sender="";
        String to="";
        String cc="";
        String replyT="";
        String sub="";
        String s_enco="";
        String date="";
        String priori="";
        String body="";
        String b_enco="";
        String t_type="";
        String c_type="";
        String c_disp="";
        String m_id="";
        String mime_boundary = "";
        String mime = "";
        String stream="";
        String xmailer = "";
        String email_size;
        //string f;
        String emailid;
        int cc_empty;
        int envelope_recipients_invalid=0;
        int envelope_recipients_valid=0;
        // int counter = 1;
        int message_id;
        int char_encoding_base64=0;
        int char_encoding_big5=0;
        int char_encoding_gb2312=0;
        int char_encoding_gb=0;
        int char_encoding_8bit=0;
        int char_encoding_7bit=0;
        int char_encoding_quoted_printable=0;
        int from_domain_aol=0;
        int from_domain_gmail=0;
        int from_domain=0;
        int from_domain_hotmail=0;
        int from_domain_example=0;
        //int from_domain_example_invalid = 0;
        //int from_domain_example_similarity = 0;
            int from_domain_mil=0;
            int from_domain_yahoo=0;
            int reply_to_gmail=0;
            int reply_to_hotmail=0;
            int reply_to_example=0;
            int reply_to_yahoo=0;
            int link = 0;
            int link_exe=0;
            int link_htm=0;
            int link_zip=0;
            int mime_boundary_2rfk=0;
            int attachment=0;
            int attachment_doc=0;
            int attachment_htm=0;
            int attachment_mdb=0;
            int attachment_pdf=0;
            int attachment_ppt=0;
            int attachment_xls=0;
            int x_mailer_aol = 0;
            int x_mailer_aspnet = 0;
            int x_mailer_blat = 0;
            int x_mailer_dreammail = 0;
            int x_mailer_extreme_mail_express = 0;
            int x_mailer_foxmail = 0;
            int x_mailer_ghost_mail = 0;
            int x_mailer_outlook_express = 0;
            int x_mailer_yahoomail = 0;
            int envelope_recipients_total = 0;
            int sum = 0;
            int envelope_recipients_average_joblevel = 0;
            String[] recipient = new String[envelope_recipients_total];

      public void read()
     {
         try
         {     
         Class.forName("com.mysql.jdbc.Driver");
         Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/emailspam","root","");
         Statement st1=conn.createStatement();
       
         ResultSet rs=st1.executeQuery("select * from users");
         
         
                
        // ResultSet rs1=st1.executeQuery("insert into users('Priyanka.Thomake@gmail.com','26081993')");
        // ResultSet rs=st1.executeQuery("select TOP 2 username,password from users ");       
       while(rs.next())
       {

    Properties props = new Properties();
        props.setProperty("mail.store.protocol", "imaps");
        
            Session session = Session.getInstance(props, null);
            Store store = session.getStore();
           
            store.connect("imap.gmail.com",rs.getString(1), rs.getString(2));
            //Folder inbox = store.getFolder("[Gmail]/Spam");
             Folder inbox = store.getFolder("[Gmail]/Spam");
           //Folder inbox = store.getFolder("INBOX");
            
            inbox.open(Folder.READ_ONLY);            
            
            int cnt=inbox.getMessageCount();
            
            for(int i=cnt-1;i>=2;i--)
            {
                
                
            Message msg = inbox.getMessage(i); 
            
            Enumeration en=msg.getAllHeaders();
            
            while(en.hasMoreElements())
            {
                Header h=(Header)en.nextElement();
                
                System.out.println("aaa..."+h.getName());
               
                if(h.getName().equals(("Delivered-To")))
                    to=h.getValue();
                else if(h.getName().equals(("Date")))
                    date=h.getValue();
                else if(h.getName().equals(("From")))
                    from=h.getValue();
                else if(h.getName().equals(("Reply-to")))
                    replyT=h.getValue();
                
                else if(h.getName().equals(("Subject")))
                
                    try
                    {
                    sub=h.getValue();
                
                        if(sub==null)
                        {
                            sub="";
                        }
                    }catch(Exception e)   
                    {
                        sub="";
                    }
                            
                
                else if(h.getName().equals(("X-Priority")))
                    priori=h.getValue();
                else if(h.getName().equals(("X-Mailer")))
                    xmailer=h.getValue();
                else if(h.getName().equals(("Message-ID")))
                    m_id=h.getValue();
                else if(h.getName().equals(("MIME-Version")))
                    mime=h.getValue();
                else if(h.getName().equals(("Content-Type")))
                    c_type=h.getValue();
                else if(h.getName().equals((" boundary")))
                    mime_boundary=h.getValue();
               else
                    if(h.getName().equals("Content-Transfer-Encoding"))
                     t_type=h.getValue();
                        
                        
               /* else if(h.getName().equals((" ")))
                    cc=h.getValue();
                else if(h.getName().equals((" ")))
                    s_enco=h.getValue();
                else if(h.getName().equals((" ")))
                    body=h.getValue();
                else if(h.getName().equals((" ")))
                    b_enco=h.getValue();
                else if(h.getName().equals((" ")))
                    c_disp=h.getValue();
                else if(h.getName().equals((" ")))
                    stream=h.getValue();
                else if(h.getName().equals((" ")))
                     t_type=h.getValue();
                       */
                
                System.out.println(h.getName()+"   "+h.getValue());                
            }
             Address[]rec =msg.getRecipients(Message.RecipientType.CC);
             
             if(rec==null)
             {
                 cc="";
             }
             else
                 
             if(rec.length>=1)
             {
                 cc=rec[0].toString();
             }
            
           
            
            
            
            String from="";
            Address[] in = msg.getFrom();
            for (Address address : in) {
                System.out.println("FROM:" + address.toString());
                from=from+address.toString()+" ";
            
            }
            
          Multipart mp=null;
            Object obj=msg.getContent();
            
            if(obj instanceof Multipart)
            {
                  mp = (Multipart) msg.getContent();
            }

            if(mp!=null)
            {
            
            BodyPart bp;
            
            bp= mp.getBodyPart(1);
            
            
            System.out.println("SENT DATE:" + msg.getSentDate());
            System.out.println("SUBJECT:" + msg.getSubject());
            System.out.println("CONTENT:" + bp.getContent());
            
            
            
            
     
            String content=bp.getContent().toString();
            
body=content;            
           /* FileWriter fw=new FileWriter("d:\\explore.html");
            fw.write(content);
            fw.flush();
            fw.close();*/
          //  content=content.replaceAll("'","");
         //   content=content.replaceAll(",","");
            
            
            String attach="";
            if(bp.getDisposition()!=null)
            {
            if(bp.getDisposition().equals("ATTACHMENT"))                
            {
                attach=bp.getContentType();
                c_disp=attach;
            }
            }
            
           /* if(content.length()<3999)
            {
                
            }
            else
            {
              //  System.out.println("CONTENT:" + content.substring(0,3999));
             
             content=content.substring(0,3999);
                
            }
           */

            
            
            
            
  /*        FileInputStream    fis = new FileInputStream("d:\\explore.html");

  PreparedStatement stmt= conn.prepareStatement("Insert into spambox values(?,?,?,?,?)");

  
  
  stmt.setString(1,from);
  stmt.setString(2,msg.getSentDate().toString());
  stmt.setString(3,msg.getSubject());
  
  stmt.setBinaryStream(4, fis, (int)fis.available());
   stmt.setString(5,attach);
   stmt.executeUpdate();         
*/  
   PreparedStatement stmt1= conn.prepareStatement("Insert into feature_inbox values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   
   stmt1.setString(1,from);
   stmt1.setString(2,to);
   stmt1.setString(3,cc);
   stmt1.setString(4,replyT);
   stmt1.setString(5,sub);
   stmt1.setString(6,s_enco);
   stmt1.setString(7,date);
   stmt1.setString(8,priori);
   stmt1.setString(9,body.substring(1,10));
   stmt1.setString(10,b_enco);
   stmt1.setString(11,t_type);
   stmt1.setString(12,c_type);
   stmt1.setString(13,c_disp);
   stmt1.setString(14,m_id);
   stmt1.setString(15,mime_boundary);
   stmt1.setString(16,mime);
   stmt1.setString(17,stream);
   stmt1.setString(18,xmailer);
   
   stmt1.executeUpdate();  
          
          
            //String q="Insert into spambox values('"+from+"','"+msg.getSentDate()+"','"+msg.getSubject()+"','"+content+"','"+attach+"')";
            
         //  System.out.println(q);
           //st1.executeUpdate(q);
   
            
            
                       if(cc.equals(""))
                            cc_empty = 1;
                            // Console.WriteLine("CC field: "+cc_empty);
                           else
                            cc_empty = 0;
                            //Console.WriteLine(cc_empty);
                      
                       
                       email_size = stream;
                       
                    if (email_size.equals(""))
                    {
                        email_size = "0";
                    }
                    
                    //Console.WriteLine(email_size);

                    if (m_id.contains("[redacted]"))
                    {
                        message_id = 1;
                        //Console.WriteLine(message_id);
                        
                    }
                    else
                    {
                        message_id = 0;
                        //Console.WriteLine(message_id);
                    }
                    
                   
         
                        if(t_type.trim().equals ("base64:"))
                            char_encoding_base64 = 1;
                           
                           

                        if(t_type.trim().equals("big5:"))
                            char_encoding_big5 = 1;
                            

                        if(t_type.trim().equals("gb2312"))
                            char_encoding_gb2312 = 1;
                           
                         

                         if(t_type.trim().equals("gbk"))
                     {
                          char_encoding_gb = 1;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            char_encoding_8bit = 0;
                            char_encoding_quoted_printable = 0;
                            //Console.WriteLine("Encoding of gbk :" + char_encoding_gbk);
                            break;
                      }
                        if(t_type.trim().equals("quoted-printable"))
                         {
                            char_encoding_quoted_printable = 1;
                            char_encoding_gb = 0;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            char_encoding_8bit = 0;  
                            
                          
                   } 
                  
                            if(t_type.trim().equals("8bit"))
                       {
                            char_encoding_8bit = 1;
                            char_encoding_quoted_printable = 0;
                            char_encoding_gb = 0;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            //Console.WriteLine("Encoding of 8bit:" + char_encoding_8bit);
                           
                      }
                        if(t_type.trim().equals("7bit"))
                         {
                            char_encoding_7bit = 1;
                            char_encoding_quoted_printable = 0;
                            char_encoding_gb = 0;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            char_encoding_8bit = 0;
                            //Console.WriteLine("Encoding of 7bit:" + char_encoding_7bit);
                            
                     }
                       

                           /* String g = t_type.trim();
                            if (g.StartsWith("base64"))
                            {
                                char_encoding_base64 = 1;
                            }
                            else
                            {
                                char_encoding_7bit = 0;
                                char_encoding_quoted_printable = 0;
                                char_encoding_gbk = 0;
                                char_encoding_big5 = 0;
                                char_encoding_gb2312 = 0;
                                char_encoding_8bit = 0;
                            }
                            break;*/
      // } 
       
                   // }

        
               // from features...

                    if (from.contains("@aol") == true)
                    {
                        from_domain_aol = 1;
                        //Console.WriteLine("From Aol Domain:" + from_domain_aol);
                    }
                    else
                    {
                        from_domain_aol = 0;
                    }


                    if (from.contains("@gmail.com") == true)
                    {

                        from_domain_gmail = 1;
                        //Console.WriteLine("From Gmail Domain:" + from_domain_gmail);
                    }
                    else
                    {
                        from_domain_gmail = 0;
                    }

                    if (from.contains("@gov") == true)
                    {
                        from_domain= 1;
                        //Console.WriteLine("From Gov Domain:" + from_domain_gov);
                    }
                    else
                    {
                        from_domain = 0;
                    }

                    if (from.contains("@hotmail") == true)
                    {
                        from_domain_hotmail = 1;
                        //Console.WriteLine("From Hotmail Domain:" + from_domain_hotmail);
                    }
                    else
                    {
                        from_domain_hotmail = 0;
                    }

                    if (from.contains("@example.com") == true)
                    {
                        from_domain_example = 1;
                        //Console.WriteLine("From Example Domain:" + from_domain_example);
                    }
                    else
                    {
                        from_domain_example = 0;
                    }

                    /* case "example invalid":
                        from_domain_example_invalid = 1;
                        Console.WriteLine("From Example-Invalid Domain:" + from_domain_example_invalid);
                        break;

                    case "example similarity":
                        from_domain_example_similarity = 1;
                        Console.WriteLine("From Example-Similarity Domain:" + from_domain_example_similarity);
                        break;*/

                    if (from.contains("@mil") == true)
                    {
                        from_domain_mil = 1;
                        //Console.WriteLine("From Mil Domain:" + from_domain_mil);
                    }
                    else
                    {
                        from_domain_mil = 0;
                    }


                    if (from.contains("@yahoo") == true)
                    {
                        from_domain_yahoo = 1;
                        //Console.WriteLine("From Yahoo Domain:" + from_domain_yahoo);
                    }
                    else
                    {
                        from_domain_yahoo = 0;
                    }

                    // Reply to Features
                    if (replyT.contains("@gmail") == true)
                    {
                        reply_to_gmail = 1;
                        //Console.WriteLine("Reply to gmail" + reply_to_gmail);
                    }
                    else
                    {
                        reply_to_gmail = 0;
                    }
                    if (replyT.contains("@hotmail") == true)
                    {
                        reply_to_hotmail = 1;
                        //Console.WriteLine("Reply to hotmail" + reply_to_hotmail);
                    }
                    else
                    {
                        reply_to_hotmail = 0;
                    }
                    if (replyT.contains("@example") == true)
                    {
                        reply_to_example = 1;
                        //Console.WriteLine("Reply to gmail" + reply_to_example);
                    }
                    else
                    {
                        reply_to_example = 0;
                    }
                    if (replyT.contains("@yahoo") == true)
                    {
                        reply_to_yahoo = 1;
                        //Console.WriteLine("Reply to yahoo" + reply_to_yahoo);
                    }
                    else
                    {
                        reply_to_yahoo = 0;
                    }     
                    
                     // Body Features 

                    int s = body.indexOf("<a href");

                    if (!body.equals(""))
                    {
                        if (body.contains("a href="))
                        {
                            link = 1;
                        }
                        else
                        {
                            link = 0;
                        }
                    }
                    if(link==1)
                    {
                        String hlink = body.substring(s);
                        if(hlink.contains(".exe"))
                        {
                            link_exe = 1;
                            //Console.WriteLine(" Body contains link to an exe file ", +link_exe);
                        }
                        else
                        {
                            link_exe = 0;
                        }

                        if (hlink.contains(".htm") || hlink.contains(".html"))
                        {
                            link_htm = 1;
                            //Console.WriteLine(" Body contains link to a htm file ", +link_htm);
                        }
                        else
                        {
                            link_htm = 0;
                        }

                        if (hlink.contains(".zip"))
                        {
                            link_zip = 1;
                            //Console.WriteLine(" Body contains link to a zip file ", +link_zip);
                        }
                        else
                        {
                            link_zip = 0;
                        }
                    }
                    else
                    {
                        link_exe = 0;
                        link_htm = 0;
                        link_zip = 0;
                    }


                      // Mime boundary features

                    // SPCScan.Program.boundary = c_type.Split('=');

                    if (mime_boundary.startsWith("2rfk"))
                    {
                        mime_boundary_2rfk = 1;
                    }
                    else
                    {
                        mime_boundary_2rfk = 0;
                    }
                    
                     // Attachment Features 

                    if (c_disp.contains("attachment"))
                    {
                        attachment = 1;
                    }
                    else
                    {
                        attachment = 0;
                        attachment_doc = 0;
                        attachment_htm = 0;
                        attachment_mdb = 0;
                        attachment_pdf = 0;
                        attachment_ppt = 0;
                        attachment_xls = 0;

                    }

                        //if(attachment == 1)
                        {

                            if (c_disp.contains(".doc"))
                            {
                            attachment_doc = 1;
                            }
                            if (c_disp.contains(".htm"))
                            {
                            attachment_htm = 1;
                            }
                           if (c_disp.contains(".mdb"))
                           {
                            attachment_mdb = 1;
                           }
                           if (c_disp.contains(".pdf"))
                           {
                            attachment_pdf = 1;
                           }
                           if (c_disp.contains(".ppt"))
                           {
                            attachment_ppt = 1;
                           }
                           if (c_disp.contains(".xls"))
                           {
                            attachment_xls = 1;
                           }
                    }
                    
                        // Xmailer Features 

                    if (!xmailer.equals(""))
                    {
                        if(xmailer.contains("AOL"))
                        {
                            x_mailer_aol=1;
                        }
                        else
                        {
                            x_mailer_aol=0;
                        }
                        if(xmailer.contains("aspnet"))
                        {
                            x_mailer_aspnet=1;
                        }
                        else
                        {
                            x_mailer_aspnet=0;
                        }
                        if(xmailer.contains("blat"))
                        {
                            x_mailer_blat=1;
                        }
                        else
                        {
                            x_mailer_blat=0;
                        }
                        if(xmailer.contains("DreamMail"))
                        {
                            x_mailer_dreammail=1;
                        }
                        else
                        {
                            x_mailer_dreammail=0;
                        }
                        if(xmailer.contains("ExtremeMail Express"))
                        {
                            x_mailer_extreme_mail_express=1;
                        }
                        else
                        {
                            x_mailer_extreme_mail_express=0;
                        }
                        if(xmailer.contains("Foxmail"))
                        {
                            x_mailer_foxmail=1;
                        }
                        else
                        {
                            x_mailer_foxmail=0;
                        }
                        if(xmailer.contains("Ghost Mail"))
                        {
                            x_mailer_ghost_mail=1;
                        }
                        else
                        {
                            x_mailer_ghost_mail=0;
                        }
                        if(xmailer.contains("Outlook Express"))
                        {
                            x_mailer_outlook_express=1;
                        }
                        else
                        {
                            x_mailer_outlook_express=0;
                        }
                        if(xmailer.contains("YahooMail"))
                        {
                            x_mailer_yahoomail=1;
                        }
                        else
                        {
                            x_mailer_yahoomail=0;
                        }
                    }
                    else
                    {
                        x_mailer_aol=0;
                        x_mailer_aspnet=0;
                        x_mailer_blat=0;
                        x_mailer_dreammail=0;
                        x_mailer_extreme_mail_express=0;
                        x_mailer_foxmail=0;
                        x_mailer_ghost_mail=0;
                        x_mailer_outlook_express=0;
                        x_mailer_yahoomail=0;
                    } //end else


            }
   PreparedStatement stmt= conn.prepareStatement("Insert into feature_table2 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        
   if(email_size==null)
   {
       email_size="0";
   }
   stmt.setInt(1,cc_empty);
   stmt.setString(2,email_size);
   stmt.setInt(3,message_id);
   stmt.setInt(4,char_encoding_base64);
   stmt.setInt(5,char_encoding_big5);
   stmt.setInt(6,char_encoding_gb2312);
   stmt.setInt(7,char_encoding_gb);
   stmt.setInt(8,char_encoding_8bit);
   stmt.setInt(9,char_encoding_7bit);
   stmt.setInt(10,char_encoding_quoted_printable);
   stmt.setInt(11,from_domain_aol);
   stmt.setInt(12,from_domain_gmail);
   stmt.setInt(13,from_domain);
   stmt.setInt(14,from_domain_hotmail);
   stmt.setInt(15,from_domain_example);
   stmt.setInt(16,from_domain_mil);
   stmt.setInt(17,from_domain_yahoo);
   stmt.setInt(18,reply_to_gmail);
   stmt.setInt(19,reply_to_hotmail);
   stmt.setInt(20,reply_to_example);
   stmt.setInt(21,reply_to_yahoo);
   stmt.setInt(22,link);
   stmt.setInt(23,link_exe);
   stmt.setInt(24,link_htm);
   stmt.setInt(25,link_zip);
   stmt.setInt(26,mime_boundary_2rfk);
   stmt.setInt(27,attachment);
   stmt.setInt(28,attachment_doc);
   stmt.setInt(29,attachment_htm);
   stmt.setInt(30,attachment_mdb);
   stmt.setInt(31,attachment_pdf);
   stmt.setInt(32,attachment_ppt);
   stmt.setInt(33,attachment_xls);
   stmt.setInt(34,x_mailer_aol);
   stmt.setInt(35,x_mailer_aspnet);
   stmt.setInt(36,x_mailer_blat);
   stmt.setInt(37,x_mailer_dreammail);
   stmt.setInt(38,x_mailer_extreme_mail_express);
   stmt.setInt(39,x_mailer_foxmail);
   stmt.setInt(40,x_mailer_ghost_mail);
   stmt.setInt(41,x_mailer_outlook_express);
   stmt.setInt(42,x_mailer_yahoomail);
   stmt.setInt(43,envelope_recipients_total);
   stmt.setInt(44,envelope_recipients_valid);
   stmt.setInt(45,envelope_recipients_invalid);
   stmt.setInt(46,envelope_recipients_average_joblevel);
   stmt.setString(47,m_id);
  
 
   
   stmt.executeUpdate();  
         }
            }
           
            
         }// end try
      catch(Exception ee)
            {
                 System.out.println(ee);
            } //end catch  
     }
 }