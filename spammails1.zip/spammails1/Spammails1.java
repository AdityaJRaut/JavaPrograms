package spammails1;
import java.sql.*;
import java.io.*;
import javax.mail.*;
import java.util.*;
import javax.mail.Multipart;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.parser.ParserDelegator;
public class Spammails1
{
public static void main(String[] args)
{
        // TODO code application logic here   
}
}
class GmailInbox
{
        String id, pwd;
        String from="";
        String to="";
        String cc="";
        String replyT="";
        String sub="";
        String s_enco="";
        String date="";
        String priori="";
        String body="";
        String b_enco="";
        String t_type="";
        String c_type="";
        String c_disp="";
        String m_id="";
        String mime_boundary = "";
        String mime = "";
        String stream="";
        String xmailer = "";
        String email_size;
        String emailid;
        int cc_empty;
        int envelope_recipients_invalid=0;
        int envelope_recipients_valid=0;
        int message_id;
        int char_encoding_base64=0;
        int char_encoding_big5=0;
        int char_encoding_gb2312=0;
        int char_encoding_gb=0;
        int char_encoding_8bit=0;
        int char_encoding_7bit=0;
        int char_encoding_quoted_printable=0;
        int from_domain_aol=0;
        int from_domain_gmail=0;
        int from_domain=0;
        int from_domain_hotmail=0;
        int from_domain_example=0;
        int from_domain_mil=0;
        int from_domain_yahoo=0;
        int reply_to_gmail=0;
        int reply_to_hotmail=0;
        int reply_to_example=0;
        int reply_to_yahoo=0;
        int link = 0;
        int link_exe=0;
        int link_htm=0;
        int link_zip=0;
        int mime_boundary_2rfk=0;
        int attachment=0;
        int attachment_doc=0;
        int attachment_htm=0;
        int attachment_mdb=0;
        int attachment_pdf=0;
        int attachment_ppt=0;
        int attachment_xls=0;
        int x_mailer_aol = 0;
        int x_mailer_aspnet = 0;
        int x_mailer_blat = 0;
        int x_mailer_dreammail = 0;
        int x_mailer_extreme_mail_express = 0;
        int x_mailer_foxmail = 0;
        int x_mailer_ghost_mail = 0;
        int x_mailer_outlook_express = 0;
        int x_mailer_yahoomail = 0;
        int envelope_recipients_total = 0;
        int sum = 0;
        int envelope_recipients_average_joblevel = 0;
        String[] recipient = new String[envelope_recipients_total];
        public void read()
     {
       try
         {     
         Class.forName("com.mysql.jdbc.Driver");
         Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/emailspam","root","");
         Statement st1=conn.createStatement();
         ResultSet rs=st1.executeQuery("select * from users");
         while(rs.next())
         {
         Properties props = new Properties();
         props.setProperty("mail.store.protocol", "imaps");
         Session session = Session.getInstance(props, null);
         Store store = session.getStore();
         store.connect("imap.gmail.com",rs.getString(1), rs.getString(2));
         Folder inbox = store.getFolder("[Gmail]/Spam");
         inbox.open(Folder.READ_ONLY);            
         int i=inbox.getMessageCount();
         for(i=1;i<=3;i++)
            {
              Message msg = inbox.getMessage(i); 
              Enumeration en=msg.getAllHeaders();
         while(en.hasMoreElements())
            {
              Header h=(Header)en.nextElement();
              System.out.println("spam_detection"+h.getName());
              if(h.getName().equals(("Delivered-To")))
                   to=h.getValue();
              else if(h.getName().equals(("Date")))
                   date=h.getValue();
              else if(h.getName().equals(("From")))
                   from=h.getValue();
              else if(h.getName().equals(("Reply-to")))
                   replyT=h.getValue();
              else if(h.getName().equals(("Subject")))
                
              try
              {
                  sub=h.getValue();
                  if(sub==null)
                  {
                      sub="";
                  }
                  
              }
              catch(Exception e)   
              {
                      System.out.println("no subject");
              }
              else if(h.getName().equals(("X-Priority")))
                    priori=h.getValue();
              else if(h.getName().equals(("X-Mailer")))
                    xmailer=h.getValue();
              else if(h.getName().equals(("Message-ID")))
                    m_id=h.getValue();
              else if(h.getName().equals(("MIME-Version")))
                    mime=h.getValue();
              else if(h.getName().equals(("Content-Type")))
                    c_type=h.getValue();
              else if(h.getName().equals((" boundary")))
                    mime_boundary=h.getValue();
              else if(h.getName().equals("Content-Transfer-Encoding"))
                     t_type=h.getValue();
              System.out.println(h.getName()+"   "+h.getValue());                
            }
             Address[]rec =msg.getRecipients(Message.RecipientType.CC);
              if(rec==null)
             {
                 cc="";
             }
              else if(rec.length>=1)
             {
                 cc=rec[0].toString();
             }
            String from;
             from = "";
            Address[] in = msg.getFrom();
            for (Address address : in) 
            {
            System.out.println("FROM:" + address.toString());
            from=from+address.toString()+" ";
            }
            Multipart mp=null;
            Object obj=msg.getContent();
            if(obj instanceof Multipart)
            {
                  mp = (Multipart) msg.getContent();
            }
            if(mp!=null)
            {
                  BodyPart bp;
                  bp= mp.getBodyPart(1);
            System.out.println("SENT DATE:" + msg.getSentDate());
            System.out.println("SUBJECT:" + msg.getSubject());
            System.out.println("CONTENT:" + bp.getContent());
            String content=bp.getContent().toString();
            body=content;            
            //FileWriter fw=new FileWriter("d:\\explore.html");
            //fw.write(content);
            //fw.flush();
            //fw.close();
            String attach;
                  attach = "";
            if(bp.getDisposition()!=null)
            {
            if(bp.getDisposition().equals("ATTACHMENT"))                
            {
                attach=bp.getContentType();
                c_disp=attach;
            }
            }
   PreparedStatement stmt1= conn.prepareStatement("Insert into feature_spam values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   
   stmt1.setString(1,from);
   stmt1.setString(2,to);
   stmt1.setString(3,cc);
   stmt1.setString(4,replyT);
   stmt1.setString(5,sub);
   stmt1.setString(6,s_enco);
   stmt1.setString(7,date);
   stmt1.setString(8,priori);
   stmt1.setString(9,body.substring(1,10));
   stmt1.setString(10,b_enco);
   stmt1.setString(11,t_type);
   stmt1.setString(12,c_type);
   stmt1.setString(13,c_disp);
   stmt1.setString(14,m_id);
   stmt1.setString(15,mime_boundary);
   stmt1.setString(16,mime);
   stmt1.setString(17,stream);
   stmt1.setString(18,xmailer);
   stmt1.executeUpdate();  
                            if(cc.equals(""))
                            cc_empty = 1;
                            else
                            cc_empty = 0;
                            email_size = stream;
                            if (email_size.equals(""))
                    {
                        email_size = "0";
                    }
                    if (m_id.contains("[redacted]"))
                    {
                        message_id = 1;
                        
                    }
                    else
                    {
                        message_id = 0;
                       
                    }
                    if(t_type.trim().equals ("base64:"))
                            char_encoding_base64 = 1;
                    if(t_type.trim().equals("big5:"))
                            char_encoding_big5 = 1;
                    if(t_type.trim().equals("gb2312"))
                            char_encoding_gb2312 = 1;
                    if(t_type.trim().equals("gbk"))
                     {
                            char_encoding_gb = 1;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            char_encoding_8bit = 0;
                            char_encoding_quoted_printable = 0;
                            //Console.WriteLine("Encoding of gbk :" + char_encoding_gbk);
                            break;
                      }
                        if(t_type.trim().equals("quoted-printable"))
                         {
                            char_encoding_quoted_printable = 1;
                            char_encoding_gb = 0;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            char_encoding_8bit = 0;  
                         } 
                        if(t_type.trim().equals("8bit"))
                       {
                            char_encoding_8bit = 1;
                            char_encoding_quoted_printable = 0;
                            char_encoding_gb = 0;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            //Console.WriteLine("Encoding of 8bit:" + char_encoding_8bit);
                       }
                        if(t_type.trim().equals("7bit"))
                         {
                            char_encoding_7bit = 1;
                            char_encoding_quoted_printable = 0;
                            char_encoding_gb = 0;
                            char_encoding_base64 = 0;
                            char_encoding_big5 = 0;
                            char_encoding_gb2312 = 0;
                            char_encoding_8bit = 0;
                            //Console.WriteLine("Encoding of 7bit:" + char_encoding_7bit);
                         }
                        // from features...
                        if (from.contains("@aol") == true)
                    {
                            from_domain_aol = 1;
                            //Console.WriteLine("From Aol Domain:" + from_domain_aol);
                    }
                        else
                    {
                            from_domain_aol = 0;
                    }


                        if (from.contains("@gmail.com") == true)
                    {

                            from_domain_gmail = 1;
                            //Console.WriteLine("From Gmail Domain:" + from_domain_gmail);
                    }
                        else
                    {
                            from_domain_gmail = 0;
                    }

                        if (from.contains("@gov") == true)
                    {
                            from_domain= 1;
                            //Console.WriteLine("From Gov Domain:" + from_domain_gov);
                    }
                        else
                    {
                            from_domain = 0;
                    }

                        if (from.contains("@hotmail") == true)
                    {
                            from_domain_hotmail = 1;
                            //Console.WriteLine("From Hotmail Domain:" + from_domain_hotmail);
                    }
                        else
                    {
                            from_domain_hotmail = 0;
                    }
                        if (from.contains("@example.com") == true)
                    {
                            from_domain_example = 1;
                            //Console.WriteLine("From Example Domain:" + from_domain_example);
                    }
                    else
                    {
                        from_domain_example = 0;
                    }
                        /* case "example invalid":
                        from_domain_example_invalid = 1;
                        Console.WriteLine("From Example-Invalid Domain:" + from_domain_example_invalid);
                        break;
                        * case "example similarity":
                        from_domain_example_similarity = 1;
                        Console.WriteLine("From Example-Similarity Domain:" + from_domain_example_similarity);
                        break;*/
                    if (from.contains("@mil") == true)
                    {
                        from_domain_mil = 1;
                        //Console.WriteLine("From Mil Domain:" + from_domain_mil);
                    }
                    else
                    {
                        from_domain_mil = 0;
                    }
                    if (from.contains("@yahoo") == true)
                    {
                        from_domain_yahoo = 1;
                        //Console.WriteLine("From Yahoo Domain:" + from_domain_yahoo);
                    }
                    else
                    {
                        from_domain_yahoo = 0;
                    }

                    // Reply to Features
                    if (replyT.contains("@gmail") == true)
                    {
                        reply_to_gmail = 1;
                        //Console.WriteLine("Reply to gmail" + reply_to_gmail);
                    }
                    else
                    {
                        reply_to_gmail = 0;
                    }
                    if (replyT.contains("@hotmail") == true)
                    {
                        reply_to_hotmail = 1;
                        //Console.WriteLine("Reply to hotmail" + reply_to_hotmail);
                    }
                    else
                    {
                        reply_to_hotmail = 0;
                    }
                    if (replyT.contains("@example") == true)
                    {
                        reply_to_example = 1;
                        //Console.WriteLine("Reply to gmail" + reply_to_example);
                    }
                    else
                    {
                        reply_to_example = 0;
                    }
                    if (replyT.contains("@yahoo") == true)
                    {
                        reply_to_yahoo = 1;
                        //Console.WriteLine("Reply to yahoo" + reply_to_yahoo);
                    }
                    else
                    {
                        reply_to_yahoo = 0;
                    }     
                     // Body Features ...
                    int s = body.indexOf("<a href");

                    if (!body.equals(""))
                    {
                        if (body.contains("a href="))
                        {
                            link = 1;
                        }
                        else
                        {
                            link = 0;
                        }
                    }
                    if(link==1)
                    {
                        String hlink = body.substring(s);
                        if(hlink.contains(".exe"))
                        {
                            link_exe = 1;
                            //Console.WriteLine(" Body contains link to an exe file ", +link_exe);
                        }
                        else
                        {
                            link_exe = 0;
                        }

                        if (hlink.contains(".htm") || hlink.contains(".html"))
                        {
                            link_htm = 1;
                            //Console.WriteLine(" Body contains link to a htm file ", +link_htm);
                        }
                        else
                        {
                            link_htm = 0;
                        }

                        if (hlink.contains(".zip"))
                        {
                            link_zip = 1;
                            //Console.WriteLine(" Body contains link to a zip file ", +link_zip);
                        }
                        else
                        {
                            link_zip = 0;
                        }
                    }
                    else
                    {
                        link_exe = 0;
                        link_htm = 0;
                        link_zip = 0;
                    }
                    // Mime boundary features

                    // SPCScan.Program.boundary = c_type.Split('=');
                    if (mime_boundary.startsWith("2rfk"))
                    {
                        mime_boundary_2rfk = 1;
                    }
                    else
                    {
                        mime_boundary_2rfk = 0;
                    }
                    // Attachment Features...
                    if (c_disp.contains("attachment"))
                    {
                        attachment = 1;
                    }
                    else
                    {
                        attachment = 0;
                        attachment_doc = 0;
                        attachment_htm = 0;
                        attachment_mdb = 0;
                        attachment_pdf = 0;
                        attachment_ppt = 0;
                        attachment_xls = 0;
                    }
                    //if(attachment == 1)
                        {
                if (c_disp.contains(".doc"))
                            {
                            attachment_doc = 1;
                            }
                if (c_disp.contains(".htm"))
                            {
                            attachment_htm = 1;
                            }
                if (c_disp.contains(".mdb"))
                           {
                            attachment_mdb = 1;
                           }
                if (c_disp.contains(".pdf"))
                           {
                            attachment_pdf = 1;
                           }
                if (c_disp.contains(".ppt"))
                           {
                            attachment_ppt = 1;
                           }
                if (c_disp.contains(".xls"))
                           {
                            attachment_xls = 1;
                           }
                        }
                    // Xmailer Features ...
                        if (!xmailer.equals(""))
                    {
                        if(xmailer.contains("AOL"))
                        {
                            x_mailer_aol=1;
                        }
                        else
                        {
                            x_mailer_aol=0;
                        }
                        if(xmailer.contains("aspnet"))
                        {
                            x_mailer_aspnet=1;
                        }
                        else
                        {
                            x_mailer_aspnet=0;
                        }
                        if(xmailer.contains("blat"))
                        {
                            x_mailer_blat=1;
                        }
                        else
                        {
                            x_mailer_blat=0;
                        }
                        if(xmailer.contains("DreamMail"))
                        {
                            x_mailer_dreammail=1;
                        }
                        else
                        {
                            x_mailer_dreammail=0;
                        }
                        if(xmailer.contains("ExtremeMail Express"))
                        {
                            x_mailer_extreme_mail_express=1;
                        }
                        else
                        {
                            x_mailer_extreme_mail_express=0;
                        }
                        if(xmailer.contains("Foxmail"))
                        {
                            x_mailer_foxmail=1;
                        }
                        else
                        {
                            x_mailer_foxmail=0;
                        }
                        if(xmailer.contains("Ghost Mail"))
                        {
                            x_mailer_ghost_mail=1;
                        }
                        else
                        {
                            x_mailer_ghost_mail=0;
                        }
                        if(xmailer.contains("Outlook Express"))
                        {
                            x_mailer_outlook_express=1;
                        }
                        else
                        {
                            x_mailer_outlook_express=0;
                        }
                        if(xmailer.contains("YahooMail"))
                        {
                            x_mailer_yahoomail=1;
                        }
                        else
                        {
                            x_mailer_yahoomail=0;
                        }
                    }
                    else
                    {
                        x_mailer_aol=0;
                        x_mailer_aspnet=0;
                        x_mailer_blat=0;
                        x_mailer_dreammail=0;
                        x_mailer_extreme_mail_express=0;
                        x_mailer_foxmail=0;
                        x_mailer_ghost_mail=0;
                        x_mailer_outlook_express=0;
                        x_mailer_yahoomail=0;
                    } //end else
            }
    /*PreparedStatement stmt= conn.prepareStatement("Insert into feature_table2 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        
   stmt.setInt(1,cc_empty);
   stmt.setString(2,email_size);
   stmt.setInt(3,message_id);
   stmt.setInt(4,char_encoding_base64);
   stmt.setInt(5,char_encoding_big5);
   stmt.setInt(6,char_encoding_gb2312);
   stmt.setInt(7,char_encoding_gb);
   stmt.setInt(8,char_encoding_8bit);
   stmt.setInt(9,char_encoding_7bit);
   stmt.setInt(10,char_encoding_quoted_printable);
   stmt.setInt(11,from_domain_aol);
   stmt.setInt(12,from_domain_gmail);
   stmt.setInt(13,from_domain);
   stmt.setInt(14,from_domain_hotmail);
   stmt.setInt(15,from_domain_example);
   stmt.setInt(16,from_domain_mil);
   stmt.setInt(17,from_domain_yahoo);
   stmt.setInt(18,reply_to_gmail);
   stmt.setInt(19,reply_to_hotmail);
   stmt.setInt(20,reply_to_example);
   stmt.setInt(21,reply_to_yahoo);
   stmt.setInt(22,link);
   stmt.setInt(23,link_exe);
   stmt.setInt(24,link_htm);
   stmt.setInt(25,link_zip);
   stmt.setInt(26,mime_boundary_2rfk);
   stmt.setInt(27,attachment);
   stmt.setInt(28,attachment_doc);
   stmt.setInt(29,attachment_htm);
   stmt.setInt(30,attachment_mdb);
   stmt.setInt(31,attachment_pdf);
   stmt.setInt(32,attachment_ppt);
   stmt.setInt(33,attachment_xls);
   stmt.setInt(34,x_mailer_aol);
   stmt.setInt(35,x_mailer_aspnet);
   stmt.setInt(36,x_mailer_blat);
   stmt.setInt(37,x_mailer_dreammail);
   stmt.setInt(38,x_mailer_extreme_mail_express);
   stmt.setInt(39,x_mailer_foxmail);
   stmt.setInt(40,x_mailer_ghost_mail);
   stmt.setInt(41,x_mailer_outlook_express);
   stmt.setInt(42,x_mailer_yahoomail);
   stmt.setInt(43,envelope_recipients_total);
   stmt.setInt(44,envelope_recipients_valid);
   stmt.setInt(45,envelope_recipients_invalid);
   stmt.setInt(46,envelope_recipients_average_joblevel);
   stmt.setString(47,m_id);
  
 
 
   
   stmt.executeUpdate();  */
         }
            }
           
            
         }// end try
     catch(Exception ee)
            {
                 System.out.println(ee);
            } //end catch
     }
 
}
class GmailInbox1
{
        String id, pwd;
        String from="";
        String to="";
        String cc="";
        String replyT="";
        String sub="";
        String s_enco="";
        String date="";
        String priori="";
        String body="";
        String b_enco="";
        String t_type="";
        String c_type="";
        String c_disp="";
        String m_id="";
        String mime_boundary = "";
        String mime = "";
        String stream="";
        String xmailer = "";
        String email_size;
        String emailid;
        int cc_empty;
        int envelope_recipients_invalid=0;
        int envelope_recipients_valid=0;
        int message_id;
        int char_encoding_base64=0;
        int char_encoding_big5=0;
        int char_encoding_gb2312=0;
        int char_encoding_gb=0;
        int char_encoding_8bit=0;
        int char_encoding_7bit=0;
        int char_encoding_quoted_printable=0;
        int from_domain_aol=0;
        int from_domain_gmail=0;
        int from_domain=0;
        int from_domain_hotmail=0;
        int from_domain_example=0;
        int from_domain_mil=0;
        int from_domain_yahoo=0;
        int reply_to_gmail=0;
        int reply_to_hotmail=0;
        int reply_to_example=0;
        int reply_to_yahoo=0;
        int link = 0;
        int link_exe=0;
        int link_htm=0;
        int link_zip=0;
        int mime_boundary_2rfk=0;
        int attachment=0;
        int attachment_doc=0;
        int attachment_htm=0;
        int attachment_mdb=0;
        int attachment_pdf=0;
        int attachment_ppt=0;
        int attachment_xls=0;
        int x_mailer_aol = 0;
        int x_mailer_aspnet = 0;
        int x_mailer_blat = 0;
        int x_mailer_dreammail = 0;
        int x_mailer_extreme_mail_express = 0;
        int x_mailer_foxmail = 0;
        int x_mailer_ghost_mail = 0;
        int x_mailer_outlook_express = 0;
        int x_mailer_yahoomail = 0;
        int envelope_recipients_total = 0;
        int sum = 0;
        int envelope_recipients_average_joblevel = 0;
        String[] recipient = new String[envelope_recipients_total];

        @SuppressWarnings("UnusedAssignment")
      public void read1()
     {
       try
         {     
         Class.forName("com.mysql.jdbc.Driver");
         Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/emailspam","root","");
         Statement st1=conn.createStatement();
       
         ResultSet rs=st1.executeQuery("select * from users");
          while(rs.next())
         {
            Properties props = new Properties();
            props.setProperty("mail.store.protocol", "imaps");
            Session session = Session.getInstance(props, null);
            Store store = session.getStore();
            store.connect("imap.gmail.com",rs.getString(1), rs.getString(2));
            Folder inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);            
            int i=inbox.getMessageCount();
            for(i=1;i<=3;i++)
            {               
                  Message msg = inbox.getMessage(i); 
                  Enumeration en=msg.getAllHeaders();
                  while(en.hasMoreElements())
            {
                Header h=(Header)en.nextElement();
                System.out.println("aaa..."+h.getName());
                if(h.getName().equals(("Delivered-To")))
                    to=h.getValue();
                else if(h.getName().equals(("Date")))
                    date=h.getValue();
                else if(h.getName().equals(("From")))
                    from=h.getValue();
                else if(h.getName().equals(("Reply-to")))
                    replyT=h.getValue();
                else if(h.getName().equals(("Subject")))
                    try
                    {
                    sub=h.getValue();
                       if(sub==null)
                        {
                            sub="";
                        }
                    }
                        catch(Exception e)   
                    {
                        System.out.println(e);
                    }
                    else if(h.getName().equals(("X-Priority")))
                        priori=h.getValue();
                    else if(h.getName().equals(("X-Mailer")))
                        xmailer=h.getValue();
                    else if(h.getName().equals(("Message-ID")))
                        m_id=h.getValue();
                    else if(h.getName().equals(("MIME-Version")))
                        mime=h.getValue();
                    else if(h.getName().equals(("Content-Type")))
                        c_type=h.getValue();
                    else if(h.getName().equals((" boundary")))
                        mime_boundary=h.getValue();
                    else if(h.getName().equals("Content-Transfer-Encoding"))
                     t_type=h.getValue();
                    System.out.println(h.getName()+"   "+h.getValue());                
            }
             Address[]rec =msg.getRecipients(Message.RecipientType.CC);
             if(rec==null)
             {
                 cc="";
             }
             else if(rec.length>=1)
             {
                 cc=rec[0].toString();
             }
            String from;
                from = "";
            Address[] in = msg.getFrom();
            for (Address address : in) 
            {
                System.out.println("FROM:" + address.toString());
                from=from+address.toString()+" ";
            }
            Multipart mp=null;
            Object obj=msg.getContent();
           // BodyPart bp;
            if(obj instanceof Multipart)
            {
                  mp = (Multipart) msg.getContent();
            }
            if(mp!=null)
            {
                try
                {
                BodyPart bp;
                bp= mp.getBodyPart(1);
            System.out.println("SENT DATE:" + msg.getSentDate());
            System.out.println("SUBJECT:" + msg.getSubject());
            System.out.println("CONTENT:" + bp.getContent());
            body=bp.getContent().toString();
            String attach; 
                      attach = "";
            //if(bp.getDisposition()!=null)
            {
            //if(bp.getDisposition().equals("ATTACHMENT"))                
            {
                attach=bp.getContentType();
                c_disp=attach;
            }
            }
                }
            catch(Exception e)
            {
              //  System.out.println("aaaaaaa");
                
            }
            }
            else
            {
            body=msg.getContent().toString();
            //FileWriter fw=new FileWriter("d:\\explore.html");
            //fw.write(content);
            //fw.flush();
            //fw.close();
            //String attach="";
            }
  PreparedStatement stmt1= conn.prepareStatement("Insert into feature_inbox values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   stmt1.setString(1,from);
   stmt1.setString(2,to);
   stmt1.setString(3,cc);
   stmt1.setString(4,replyT);
   stmt1.setString(5,sub);
   stmt1.setString(6,s_enco);
   stmt1.setString(7,date);
   stmt1.setString(8,priori);
   stmt1.setString(9,body.substring(1,10));
   stmt1.setString(10,b_enco);
   stmt1.setString(11,t_type);
   stmt1.setString(12,c_type);
   stmt1.setString(13,c_disp);
   stmt1.setString(14,m_id);
   stmt1.setString(15,mime_boundary);
   stmt1.setString(16,mime);
   stmt1.setString(17,stream);
   stmt1.setString(18,xmailer);
   stmt1.executeUpdate();  
                                if(cc.equals(""))
                                    cc_empty = 1;
                                else
                                   cc_empty = 0;
                                   email_size = stream;
                                if (email_size.equals(""))
                    {
                                    email_size = "0";
                    }
                                if (m_id.contains("[redacted]"))
                    {
                                    message_id = 1;
                    }
                                else
                    {
                                    message_id = 0;
                       
                    }
                                if(t_type.trim().equals ("base64:"))
                                    char_encoding_base64 = 1;
                                if(t_type.trim().equals("big5:"))
                                    char_encoding_big5 = 1;
                                if(t_type.trim().equals("gb2312"))
                                    char_encoding_gb2312 = 1;
                                if(t_type.trim().equals("gbk"))
                     {
                                    char_encoding_gb = 1;
                                    char_encoding_base64 = 0;
                                    char_encoding_big5 = 0;
                                    char_encoding_gb2312 = 0;
                                    char_encoding_8bit = 0;
                                    char_encoding_quoted_printable = 0;
                                    //Console.WriteLine("Encoding of gbk :" + char_encoding_gbk);
                                    break;
                      }
                                if(t_type.trim().equals("quoted-printable"))
                                {
                                    char_encoding_quoted_printable = 1;
                                    char_encoding_gb = 0;
                                    char_encoding_base64 = 0;
                                    char_encoding_big5 = 0;
                                    char_encoding_gb2312 = 0;
                                    char_encoding_8bit = 0;  
                                } 
                                if(t_type.trim().equals("8bit"))
                       {
                                    char_encoding_8bit = 1;
                                    char_encoding_quoted_printable = 0;
                                    char_encoding_gb = 0;
                                    char_encoding_base64 = 0;
                                    char_encoding_big5 = 0;
                                    char_encoding_gb2312 = 0;
                                    //Console.WriteLine("Encoding of 8bit:" + char_encoding_8bit);
                       }
                                if(t_type.trim().equals("7bit"))
                                {
                                    char_encoding_7bit = 1;
                                    char_encoding_quoted_printable = 0;
                                    char_encoding_gb = 0;
                                    char_encoding_base64 = 0;
                                    char_encoding_big5 = 0;
                                    char_encoding_gb2312 = 0;
                                    char_encoding_8bit = 0;
                                    //Console.WriteLine("Encoding of 7bit:" + char_encoding_7bit);
                                }
                       // from Features
                                if (from.contains("@aol") == true)
                                {
                                    from_domain_aol = 1;
                                    //Console.WriteLine("From Aol Domain:" + from_domain_aol);
                                }
                                else
                                {
                                    from_domain_aol = 0;
                                }
                                if (from.contains("@gmail.com") == true)
                                {
                                    from_domain_gmail = 1;
                                    //Console.WriteLine("From Gmail Domain:" + from_domain_gmail);
                                }   
                                else
                                {
                                    from_domain_gmail = 0;
                                }
                                if (from.contains("@gov") == true)
                                {
                                    from_domain= 1;
                                     //Console.WriteLine("From Gov Domain:" + from_domain_gov);
                                }
                                else
                                {
                                    from_domain = 0;
                                }
                                if (from.contains("@hotmail") == true)
                                {
                                    from_domain_hotmail = 1;
                                    //Console.WriteLine("From Hotmail Domain:" + from_domain_hotmail);
                                }
                                else
                                {
                                    from_domain_hotmail = 0;
                                }
                                if (from.contains("@example.com") == true)
                                {
                                    from_domain_example = 1;
                                    //Console.WriteLine("From Example Domain:" + from_domain_example);
                                }
                                else
                                {
                                    from_domain_example = 0;
                                }
                                /* case "example invalid":
                                from_domain_example_invalid = 1;
                                Console.WriteLine("From Example-Invalid Domain:" + from_domain_example_invalid);
                                break;
                                case "example similarity":
                                from_domain_example_similarity = 1;
                                Console.WriteLine("From Example-Similarity Domain:" + from_domain_example_similarity);
                                break;*/
                                if (from.contains("@mil") == true)
                                {
                                    from_domain_mil = 1;
                                    //Console.WriteLine("From Mil Domain:" + from_domain_mil);
                                }
                                else
                                {
                                    from_domain_mil = 0;
                                }
                                if (from.contains("@yahoo") == true)
                                {
                                    from_domain_yahoo = 1;
                                    //Console.WriteLine("From Yahoo Domain:" + from_domain_yahoo);
                                }
                                else
                                {
                                    from_domain_yahoo = 0;
                                }
                                // Reply to Features
                                if (replyT.contains("@gmail") == true)
                                {
                                    reply_to_gmail = 1;
                                    //Console.WriteLine("Reply to gmail" + reply_to_gmail);
                                }
                                else
                                {
                                    reply_to_gmail = 0;
                                }   
                                if (replyT.contains("@hotmail") == true)
                                {
                                    reply_to_hotmail = 1;
                                    //Console.WriteLine("Reply to hotmail" + reply_to_hotmail);
                                }
                                else
                                {
                                    reply_to_hotmail = 0;
                                }
                                if (replyT.contains("@example") == true)
                                {
                                    reply_to_example = 1;
                                    //Console.WriteLine("Reply to gmail" + reply_to_example);
                                }
                                else
                                {
                                    reply_to_example = 0;
                                }
                                if (replyT.contains("@yahoo") == true)
                                {
                                    reply_to_yahoo = 1;
                                    //Console.WriteLine("Reply to yahoo" + reply_to_yahoo);
                                }
                                else
                                {
                                    reply_to_yahoo = 0;
                                }     
                                // Body Features 
                                int s = body.indexOf("<a href");
                                if (!body.equals(""))
                                {
                                if (body.contains("a href="))
                                {
                                    link = 1;
                                }
                                else
                                {
                                    link = 0;
                                }
                                }
                                if(link==1)
                                {
                                    String hlink = body.substring(s);
                                if(hlink.contains(".exe"))
                                {       
                                     link_exe = 1;
                                    //Console.WriteLine(" Body contains link to an exe file ", +link_exe);
                                }
                                else
                                {
                                    link_exe = 0;
                                }
                                if (hlink.contains(".htm") || hlink.contains(".html"))
                                {
                                    link_htm = 1;
                                    //Console.WriteLine(" Body contains link to a htm file ", +link_htm);
                                }
                                else
                                {
                                    link_htm = 0;
                                }
                                if (hlink.contains(".zip"))
                                {
                                    link_zip = 1;
                                    //Console.WriteLine(" Body contains link to a zip file ", +link_zip);
                                }
                                else
                                {
                                    link_zip = 0;
                                }
                                }
                                else
                                {
                                    link_exe = 0;
                                    link_htm = 0;
                                    link_zip = 0;
                                }
                                // Mime boundary features
                                // SPCScan.Program.boundary = c_type.Split('=');
                                if (mime_boundary.startsWith("2rfk"))
                                {   
                                    mime_boundary_2rfk = 1;
                                }
                                else
                                {
                                    mime_boundary_2rfk = 0;
                                }
                                // Attachment Features 
                                if (c_disp.contains("attachment"))
                                {
                                    attachment = 1;
                                }
                                else
                                {
                                    attachment = 0;
                                    attachment_doc = 0;
                                    attachment_htm = 0;
                                    attachment_mdb = 0;
                                    attachment_pdf = 0;
                                    attachment_ppt = 0;
                                    attachment_xls = 0;
                                }
                                if (c_disp.contains(".doc"))
                                {
                                    attachment_doc = 1;
                                }
                                if (c_disp.contains(".htm"))
                                {
                                    attachment_htm = 1;
                                }
                                if (c_disp.contains(".mdb"))
                                {
                                    attachment_mdb = 1;
                                }
                                if (c_disp.contains(".pdf"))
                                {
                                    attachment_pdf = 1;
                                }
                                if (c_disp.contains(".ppt"))
                                {
                                    attachment_ppt = 1;
                                }
                                if (c_disp.contains(".xls"))
                                {
                                    attachment_xls = 1;
                                }
                                // Xmailer Features 

                                if (!xmailer.equals(""))
                                {
                                if(xmailer.contains("AOL"))
                                {
                                    x_mailer_aol=1;
                                }
                                else
                                {
                                    x_mailer_aol=0;
                                }
                                if(xmailer.contains("aspnet"))
                                {
                                    x_mailer_aspnet=1;
                                }
                                else
                                {
                                    x_mailer_aspnet=0;
                                }
                                if(xmailer.contains("blat"))
                                {
                                    x_mailer_blat=1;
                                }
                                else
                                {
                                    x_mailer_blat=0;
                                }
                                if(xmailer.contains("DreamMail"))
                                {
                                    x_mailer_dreammail=1;
                                }
                                else
                                {
                                    x_mailer_dreammail=0;
                                }
                                if(xmailer.contains("ExtremeMail Express"))
                                {
                                    x_mailer_extreme_mail_express=1;
                                }
                                else
                                {
                                    x_mailer_extreme_mail_express=0;
                                }
                                if(xmailer.contains("Foxmail"))
                                {
                                    x_mailer_foxmail=1;
                                }
                                else
                                {
                                    x_mailer_foxmail=0;
                                }
                                if(xmailer.contains("Ghost Mail"))
                                {
                                    x_mailer_ghost_mail=1;
                                }
                                else
                                {
                                    x_mailer_ghost_mail=0;
                                }
                                if(xmailer.contains("Outlook Express"))
                                {
                                    x_mailer_outlook_express=1;
                                }
                                else
                                {
                                    x_mailer_outlook_express=0;
                                }
                                if(xmailer.contains("YahooMail"))
                                {
                                    x_mailer_yahoomail=1;
                                }
                                else
                                {
                                    x_mailer_yahoomail=0;
                                }
                                }
                                else    
                                {
                                    x_mailer_aol=0;
                                    x_mailer_aspnet=0;
                                    x_mailer_blat=0;
                                    x_mailer_dreammail=0;
                                    x_mailer_extreme_mail_express=0;
                                    x_mailer_foxmail=0;
                                    x_mailer_ghost_mail=0;
                                    x_mailer_outlook_express=0;
                                    x_mailer_yahoomail=0;
                                } //end else
            }
            /*PreparedStatement stmt= conn.prepareStatement("Insert into feature_table2 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   stmt.setInt(1,cc_empty);
   stmt.setString(2,email_size);
   stmt.setInt(3,message_id);
   stmt.setInt(4,char_encoding_base64);
   stmt.setInt(5,char_encoding_big5);
   stmt.setInt(6,char_encoding_gb2312);
   stmt.setInt(7,char_encoding_gb);
   stmt.setInt(8,char_encoding_8bit);
   stmt.setInt(9,char_encoding_7bit);
   stmt.setInt(10,char_encoding_quoted_printable);
   stmt.setInt(11,from_domain_aol);
   stmt.setInt(12,from_domain_gmail);
   stmt.setInt(13,from_domain);
   stmt.setInt(14,from_domain_hotmail);
   stmt.setInt(15,from_domain_example);
   stmt.setInt(16,from_domain_mil);
   stmt.setInt(17,from_domain_yahoo);
   stmt.setInt(18,reply_to_gmail);
   stmt.setInt(19,reply_to_hotmail);
   stmt.setInt(20,reply_to_example);
   stmt.setInt(21,reply_to_yahoo);
   stmt.setInt(22,link);
   stmt.setInt(23,link_exe);
   stmt.setInt(24,link_htm);
   stmt.setInt(25,link_zip);
   stmt.setInt(26,mime_boundary_2rfk);
   stmt.setInt(27,attachment);
   stmt.setInt(28,attachment_doc);
   stmt.setInt(29,attachment_htm);
   stmt.setInt(30,attachment_mdb);
   stmt.setInt(31,attachment_pdf);
   stmt.setInt(32,attachment_ppt);
   stmt.setInt(33,attachment_xls);
   stmt.setInt(34,x_mailer_aol);
   stmt.setInt(35,x_mailer_aspnet);
   stmt.setInt(36,x_mailer_blat);
   stmt.setInt(37,x_mailer_dreammail);
   stmt.setInt(38,x_mailer_extreme_mail_express);
   stmt.setInt(39,x_mailer_foxmail);
   stmt.setInt(40,x_mailer_ghost_mail);
   stmt.setInt(41,x_mailer_outlook_express);
   stmt.setInt(42,x_mailer_yahoomail);
   stmt.setInt(43,envelope_recipients_total);
   stmt.setInt(44,envelope_recipients_valid);
   stmt.setInt(45,envelope_recipients_invalid);
   stmt.setInt(46,envelope_recipients_average_joblevel);
   stmt.setString(47,m_id);
   stmt.executeUpdate();  */
         }
         }// end try
     catch(Exception ee)
            {
                 System.out.println(ee);
            } //end catch
     }
 
}
class GmailInbox2 {
      
      String body="";
     static Hashtable ht=new Hashtable();
     public void read()
     {
         try
         {
              Class.forName("com.mysql.jdbc.Driver");
         Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/emailspam","root","");
         Statement st1=conn.createStatement();
          ResultSet rs=st1.executeQuery("select * from users");
           while(rs.next())
       {
           Properties props = new Properties();
        props.setProperty("mail.store.protocol", "imaps");
        
            Session session = Session.getInstance(props, null);
            Store store = session.getStore();
           
            store.connect("imap.gmail.com",rs.getString(1), rs.getString(2));
            //Folder inbox = store.getFolder("[Gmail]/Spam");
            //Folder inbox = store.getFolder("[Gmail]/Spam");
            Folder inbox = store.getFolder("INBOX");
            
            inbox.open(Folder.READ_ONLY);            
            
            int i=inbox.getMessageCount();
        //   for(int i=cnt-1;i>=2;i--)
            for(i=1;i<=3;i++)
           {  
            
                
              //int i=cnt-1;
             //int i=cnt-2;
                
            Message msg = inbox.getMessage(i); 
            
           
             String from="";
            Address[] in = msg.getFrom();
            for (Address address : in) {
                System.out.println("FROM:" + address.toString());
                from=from+address.toString()+" ";
            }
                 Multipart mp=null;
            Object obj=msg.getContent();
            
            if(obj instanceof Multipart)
            {
                  mp = (Multipart) msg.getContent();
            }

            if(mp!=null)
            {
            
            BodyPart bp;
            
            bp= mp.getBodyPart(1);
            
            
          //  System.out.println("SENT DATE:" + msg.getSentDate());
           // System.out.println("SUBJECT:" + msg.getSubject());
          //  System.out.println("CONTENT:" + bp.getContent());
            
     
            String content=bp.getContent().toString();            
            body=content;            
            String fdoc=body;
             BufferedReader brdoc=null;
           
                brdoc=new BufferedReader(new FileReader("content.html"));
            String strdoc="";
            while(strdoc!=null)
		{
		strdoc=brdoc.readLine();
		if(strdoc==null)
			{
			break;
			}
	//	System.out.println(strdoc);
		fdoc=fdoc+strdoc;
		}
            fdoc= extractText(fdoc);
		System.out.println(fdoc);
            
                
		StringTokenizer stdoc=new StringTokenizer(fdoc," ");
		while(stdoc.hasMoreTokens())
		{
		String xdoc=stdoc.nextToken();

		if(!xdoc.trim().equals("") )
                {
                        
                        try
                        {
			String y=find(xdoc.trim());
                        
			if(y.equals("not found"))
			{			
			htentry(xdoc);  //if not a stop word enter in hash table
                        }
                        }
                        catch(Exception ee)
                        {
                         //   System.out.println(ee);
                        }
                
                }
		
     
		}
             System.out.println(ht);   
         
             Set<String> s=ht.keySet();
             String data="";
             
             /*try
             {
                    Connection conn1 =DriverManager.getConnection("jdbc:mysql://localhost:3306/email","root","");
         Statement st2=conn.createStatement();
                 PreparedStatement stmt= conn1.prepareStatement("Insert into keyfreq values(?,?)");
  

              
            
          
		
             for(String key:s)
             {
                 data=data+key+"="+(ht.get(key)+",");
                   
                 
                 
             }
             stmt.setString(1,msg.getMessageNumber()+"");
             stmt.setString(2,data);
             stmt.executeUpdate();
             
             String []x =content.split(",");
            
            for(i=0;i<x.length;i++)
            {
                String []arr=x[i].split("=");
               
                System.out.println(arr[0]);
                 System.out.println(arr[1]);
                
                 
            }       
             
             }
              catch(Exception e)
             {
                 System.out.println(e);
                 
             }
             */
             
             
              
   
        
       
       }
       
             //end for
           
       } //end while
         } //end for
         } //end try
          catch(Exception ee)
            {
                 System.out.println(ee);
            } //end catch  
          
     } //end read()  
       String extractText(String html) throws IOException {
    final ArrayList<String> list = new ArrayList<String>();

    ParserDelegator parserDelegator = new ParserDelegator();
    HTMLEditorKit.ParserCallback parserCallback = new HTMLEditorKit.ParserCallback() {
            @Override
        public void handleText(final char[] data, final int pos) { 
            list.add(new String(data));
        }
            @Override
        public void handleStartTag(HTML.Tag tag, MutableAttributeSet attribute, int pos) { }
        public void handleEndTag(HTML.Tag t, final int pos) {  }
        public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, final int pos) { }
        public void handleComment(final char[] data, final int pos) { }
        public void handleError(final java.lang.String errMsg, final int pos) { }
    };
    parserDelegator.parse(new StringReader(html), parserCallback, true);

    String text = "";

    for(String s : list) {
        text += " " + s;
    }

    return text;
}
public static String find(String s)throws Exception
	{

		
	String first=s.substring(0,1);
        
        s=s.replaceAll(",", "");

        if(first.charAt(0)>='a' || first.charAt(0)<='z' || first.charAt(0)>='A' || first.charAt(0)<='Z')
        {
		if(first.equalsIgnoreCase("1")||first.equalsIgnoreCase("2")||first.equalsIgnoreCase("3")||first.equalsIgnoreCase("4")||first.equalsIgnoreCase("5")||first.equalsIgnoreCase("6")||first.equalsIgnoreCase("7")||first.equalsIgnoreCase("8")||first.equalsIgnoreCase("9")||first.equalsIgnoreCase("0"))

			{
			return "found";
			
			}
			
                      first=first.toLowerCase();
			String dirname1="D:\\BE SEM1\\project\\SpamMails\\src\\spammails\\stdocuments\\"+first+".txt";
			
			FileReader fr=new FileReader(dirname1);
			BufferedReader  br=new BufferedReader(fr);
			
			String str="";
			String f="";

while(str!=null)
		{
	str=br.readLine();
	f=f+str;
		}
		//System.out.print(f);
		boolean flag=false;
		
		StringTokenizer st=new StringTokenizer(f,",");
		
		while(st.hasMoreTokens())
		{
			String x=st.nextToken();
			//System.out.println(x+":"+s);
			
                        if(x.trim().equalsIgnoreCase(s.trim()))
			{			
			flag=true;
		
			}
		}

        
                if(flag==true)
			return "found";

		else
			return "not found";
		
		
	
		
		
		
	} 
        return "found";
        }

public static void htentry(String s1)
	{
	try{
		boolean flag=true;
	String index=" ";
	if(ht.isEmpty())
		{
		ht.put(s1,1);
		}
		else
		{
		Enumeration names;
		names=ht.keys();
	
		while(names.hasMoreElements())
		{
		String in="",s11="";
		index=(String)names.nextElement();

            if(index.equals(s1))
			{
			int counter=Integer.parseInt(ht.get(index)+"");
			counter++;
			ht.put(index,counter);
			flag=false;
                        
        
			break;
			}
             else
               {
            if(s1.length()>3&& index.length()>3)
              {
              if(s1.substring(0,3).equals(index.substring(0, 3)))
               {
            int counter=Integer.parseInt(ht.get(index)+"");
			counter++;
			ht.put(index,counter);
			flag=false;
                 	break;
             
                 }
                   
			  }  
               
            
            
     	       }
                   
           
         
		}//end while
        		
            if(flag==true)
			{
			ht.put(s1,new Integer(1));
			flag=true;
			}
		}
          
           
             
	}
        
	catch(Exception e)
		{System.out.println(e);	
		}
	}
     
 
} //end class
class GmailInbox3 {
      
      String body="";
     static Hashtable ht=new Hashtable();
     public void read()
     {
         try
         {
              Class.forName("com.mysql.jdbc.Driver");
         Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/email","root","");
         Statement st1=conn.createStatement();
          ResultSet rs=st1.executeQuery("select * from users");
           while(rs.next())
       {
           Properties props = new Properties();
        props.setProperty("mail.store.protocol", "imaps");
        
            Session session = Session.getInstance(props, null);
            Store store = session.getStore();
           
            store.connect("imap.gmail.com",rs.getString(1), rs.getString(2));
            //Folder inbox = store.getFolder("[Gmail]/Spam");
             Folder inbox = store.getFolder("[Gmail]/Spam");
            //Folder inbox = store.getFolder("INBOX");
            
            inbox.open(Folder.READ_ONLY);            
            
            int cnt=inbox.getMessageCount();
         //  for(int i=cnt-1;i>=2;i--)
            for(int i=1;i<cnt;i++)
           {  
            
                
              //int i=cnt-1;
             //int i=cnt-2;
                
            Message msg = inbox.getMessage(i); 
            
           
             String from="";
            Address[] in = msg.getFrom();
            for (Address address : in) {
                System.out.println("FROM:" + address.toString());
                from=from+address.toString()+" ";
            }
                 Multipart mp=null;
            Object obj=msg.getContent();
            
            if(obj instanceof Multipart)
            {
                  mp = (Multipart) msg.getContent();
            }

            if(mp!=null)
            {
            
            BodyPart bp;
            
            bp= mp.getBodyPart(1);
            
            
          //  System.out.println("SENT DATE:" + msg.getSentDate());
           // System.out.println("SUBJECT:" + msg.getSubject());
          //  System.out.println("CONTENT:" + bp.getContent());
            
     
            String content=bp.getContent().toString();            
            body=content;            
            String fdoc=body;
             BufferedReader brdoc=null;
           
                brdoc=new BufferedReader(new FileReader("content.html"));
            String strdoc="";
            while(strdoc!=null)
		{
		strdoc=brdoc.readLine();
		if(strdoc==null)
			{
			break;
			}
	//	System.out.println(strdoc);
		fdoc=fdoc+strdoc;
		}
            fdoc= extractText(fdoc);
		System.out.println(fdoc);
            
                
		StringTokenizer stdoc=new StringTokenizer(fdoc," ");
		while(stdoc.hasMoreTokens())
		{
		String xdoc=stdoc.nextToken();

		if(!xdoc.trim().equals("") )
                {
                        
                        try
                        {
			String y=find(xdoc.trim());
                        
			if(y.equals("not found"))
			{			
			htentry(xdoc);  //if not a stop word enter in hash table
                        }
                        }
                        catch(Exception ee)
                        {
                         //   System.out.println(ee);
                        }
                
                }
		
     
		}
             System.out.println(ht);   
         
             Set<String> s=ht.keySet();
             String data="";
             
             /*try
             {
                    Connection conn1 =DriverManager.getConnection("jdbc:mysql://localhost:3306/email","root","");
         Statement st2=conn.createStatement();
                 PreparedStatement stmt= conn1.prepareStatement("Insert into keyfreq_spam values(?,?)");
  


              
            
          
		
             for(String key:s)
             {
                 data=data+key+"="+(ht.get(key)+",");
                   
                 
                 
             }
             stmt.setString(1,msg.getMessageNumber()+"");
             stmt.setString(2,data);
             stmt.executeUpdate();
             
             
             String []x =content.split(",");
            
            for(i=0;i<x.length;i++)
            {
                String []arr=x[i].split("=");
               
                System.out.println(arr[0]);
                 System.out.println(arr[1]);
                
                 
            }       
             }
              catch(Exception e)
             {
                 System.out.println(e);
                 
             }
             */
             
             
              
   
        
       
       }
       
             //end for
           
       } //end while
         } //end for
         } //end try
          catch(Exception ee)
            {
                 System.out.println(ee);
            } //end catch  
          
     } //end read()  
       String extractText(String html) throws IOException {
    final ArrayList<String> list = new ArrayList<String>();

    ParserDelegator parserDelegator = new ParserDelegator();
    HTMLEditorKit.ParserCallback parserCallback = new HTMLEditorKit.ParserCallback() {
            @Override
        public void handleText(final char[] data, final int pos) { 
            list.add(new String(data));
        }
            @Override
        public void handleStartTag(HTML.Tag tag, MutableAttributeSet attribute, int pos) { }
        public void handleEndTag(HTML.Tag t, final int pos) {  }
        public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, final int pos) { }
        public void handleComment(final char[] data, final int pos) { }
        public void handleError(final java.lang.String errMsg, final int pos) { }
    };
    parserDelegator.parse(new StringReader(html), parserCallback, true);

    String text = "";

    for(String s : list) {
        text += " " + s;
    }

    return text;
}
public static String find(String s)throws Exception
	{

		
	String first=s.substring(0,1);
        
        s=s.replaceAll(",", "");

        if(first.charAt(0)>='a' || first.charAt(0)<='z' || first.charAt(0)>='A' || first.charAt(0)<='Z')
        {
		if(first.equalsIgnoreCase("1")||first.equalsIgnoreCase("2")||first.equalsIgnoreCase("3")||first.equalsIgnoreCase("4")||first.equalsIgnoreCase("5")||first.equalsIgnoreCase("6")||first.equalsIgnoreCase("7")||first.equalsIgnoreCase("8")||first.equalsIgnoreCase("9")||first.equalsIgnoreCase("0"))

			{
			return "found";
			
			}
			
                      first=first.toLowerCase();
			String dirname1="D:\\BE SEM1\\project\\SpamMails\\src\\spammails\\stdocuments\\"+first+".txt";
			
			FileReader fr=new FileReader(dirname1);
			BufferedReader  br=new BufferedReader(fr);
			
			String str="";
			String f="";

while(str!=null)
		{
	str=br.readLine();
	f=f+str;
		}
		//System.out.print(f);
		boolean flag=false;
		
		StringTokenizer st=new StringTokenizer(f,",");
		
		while(st.hasMoreTokens())
		{
			String x=st.nextToken();
			//System.out.println(x+":"+s);
			
                        if(x.trim().equalsIgnoreCase(s.trim()))
			{			
			flag=true;
		
			}
		}

        
                if(flag==true)
			return "found";

		else
			return "not found";
		
		
	
		
		
		
	} 
        return "found";
        }

public static void htentry(String s1)
	{
	try{
		boolean flag=true;
	String index=" ";
	if(ht.isEmpty())
		{
		ht.put(s1,1);
		}
		else
		{
		Enumeration names;
		names=ht.keys();
	
		while(names.hasMoreElements())
		{
		String in="",s11="";
		index=(String)names.nextElement();

            if(index.equals(s1))
			{
			int counter=Integer.parseInt(ht.get(index)+"");
			counter++;
			ht.put(index,counter);
			flag=false;
                        
        
			break;
			}
             else
               {
            if(s1.length()>3&& index.length()>3)
              {
              if(s1.substring(0,3).equals(index.substring(0, 3)))
               {
            int counter=Integer.parseInt(ht.get(index)+"");
			counter++;
			ht.put(index,counter);
			flag=false;
                 	break;
             
                 }
                   
			  }  
               
            
            
     	       }
                   
           
         
		}//end while
        		
            if(flag==true)
			{
			ht.put(s1,new Integer(1));
			flag=true;
			}
		}
          
           
             
	}
        
	catch(Exception e)
		{System.out.println(e);	
		}
	}
     
 
}